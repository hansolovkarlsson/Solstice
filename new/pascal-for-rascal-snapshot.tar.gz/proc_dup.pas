program ProcDup;
procedure foo;
begin
end;
procedure foo;
begin
end;
begin
end.
